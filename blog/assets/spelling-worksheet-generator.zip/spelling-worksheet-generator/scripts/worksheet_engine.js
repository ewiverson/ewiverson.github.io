/**
 * Spelling Worksheet Engine v2
 * 
 * HTML→PDF via Playwright. Each aid receives an exact pixel height and must fill it.
 * Row heights are explicitly computed and injected so tables stretch to fill.
 */

const { chromium } = require('playwright');
const fs = require('fs');

const PAGE_W  = 816;   // Letter at 96dpi
const PAGE_H  = 1056;
const MARGIN  = 48;
const USABLE_W = PAGE_W - MARGIN * 2;
const USABLE_H = PAGE_H - MARGIN * 2;
const TITLE_H  = 34;   // px for the sheet title bar
const GAP      = 8;    // px between aids
const HDR_H    = 26;   // px for table header rows

const DARK   = '#000000';
const MID    = '#000000';
const BORDER = '#000000';

// ── Helpers ──────────────────────────────────────────────────────────────────

// Given total height and number of data rows (+1 hdr), compute each row's px height
function rowH(totalPx, nDataRows, hdrPx = HDR_H, extraPx = 0) {
  return Math.floor((totalPx - hdrPx - extraPx) / Math.max(nDataRows, 1));
}

function pt(px, minPt = 7, maxPt = 22) {
  // Convert a pixel height to a font-size in pt that fits comfortably in that row
  const val = Math.round(px * 0.48);
  return Math.min(maxPt, Math.max(minPt, val));
}

function hdrRow(cols, widths, hdrBg = DARK) {
  return `<tr style="height:${HDR_H}px;">` +
    cols.map((c, i) => `<th style="background:${hdrBg};color:#fff;font-weight:bold;
      font-size:${pt(HDR_H)}pt;padding:2px 5px;text-align:center;
      border:1px solid ${BORDER};width:${widths[i]};overflow:hidden;">${c}</th>`).join('') +
  `</tr>`;
}

function dataCell(content, bg, rh, fs, extra = '') {
  return `<td style="background:#fff;font-size:${fs}pt;font-weight:bold;
    padding:2px 5px;border:1px solid ${BORDER};height:${rh}px;
    vertical-align:middle;overflow:hidden;${extra}">${content}</td>`;
}

function blankCell(rh) {
  return `<td style="border:none;border-bottom:2px solid #000;height:${rh}px;
    padding:1px 4px;vertical-align:bottom;">&nbsp;</td>`;
}

function sectionHdr(text, fs) {
  return `<div style="font-size:${fs}pt;font-weight:bold;text-decoration:underline;
    margin-bottom:3px;font-family:Arial,sans-serif;">${text}</div>`;
}

// ── Renderers — each returns HTML that exactly fills pxH ────────────────────

function renderWordGroups(aid, ctx, pxH) {
  const groups = Object.values(ctx.wordLists);
  const illustrations = ctx.illustrations || {};
  const maxRows = Math.max(...groups.map(g => g.words.length));

  const cols = groups.map(g => {
    const subHdrH = Math.round(pxH * 0.16);
    const nameFs  = pt(subHdrH * 0.55);
    const ruleFs  = Math.max(6, nameFs - 3);
    const dRh     = Math.floor((pxH - subHdrH - 2) / maxRows);
    const dFs     = pt(dRh * 0.55);
    const illoSz  = Math.round(dRh * 0.82);

    return '<div style="flex:1;display:flex;flex-direction:column;">' +
      '<div style="height:' + subHdrH + 'px;background:' + DARK + ';color:#fff;font-weight:bold;' +
        'font-size:' + nameFs + 'pt;border:1px solid ' + BORDER + ';display:flex;flex-direction:column;' +
        'align-items:center;justify-content:center;text-align:center;padding:2px;font-family:Arial,sans-serif;">' +
        g.name +
        '<span style="font-size:' + ruleFs + 'pt;font-weight:normal;color:#fff;">' + g.rule + '</span>' +
      '</div>' +
      g.words.map(function(w) {
        const uri = illustrations[w];
        const img = uri
          ? '<img src="' + uri + '" style="width:' + illoSz + 'px;height:' + illoSz + 'px;object-fit:contain;flex-shrink:0;"/>'
          : '<div style="width:' + illoSz + 'px;height:' + illoSz + 'px;flex-shrink:0;"></div>';
        return '<div style="height:' + dRh + 'px;background:#fff;font-size:' + dFs + 'pt;' +
          'font-weight:bold;border:1px solid ' + BORDER + ';margin-top:1px;display:flex;' +
          'align-items:center;justify-content:space-between;padding:0 6px;gap:4px;font-family:Arial,sans-serif;">' +
          '<span>' + w + '</span>' + img +
          '</div>';
      }).join('') +
    '</div>';
  }).join('');

  return '<div style="display:flex;gap:4px;height:' + pxH + 'px;overflow:hidden;">' + cols + '</div>';
}

function renderLookCoverWrite(aid, ctx, pxH) {
  const words = (aid.groups || Object.keys(ctx.wordLists))
    .flatMap(k => ctx.wordLists[k]?.words ?? []);
  const colorMap = {};
  Object.values(ctx.wordLists).forEach(g => g.words.forEach(w => colorMap[w] = g.color));

  const rh = rowH(pxH, words.length);
  const fs = pt(rh);

  const hdr = hdrRow(['Word','Write it','Write it again','One more time!'],
                      ['18%','27%','27%','28%']);
  const rows = words.map(w => `<tr style="height:${rh}px;">
    ${dataCell(w, '#fff', rh, fs, 'text-align:center;')}
    ${blankCell(rh)}${blankCell(rh)}${blankCell(rh)}
  </tr>`).join('');

  return `<div style="height:${pxH}px;overflow:hidden;font-family:Arial,sans-serif;">
    <table style="width:100%;border-collapse:collapse;table-layout:fixed;height:${pxH}px;">
      <thead>${hdr}</thead><tbody>${rows}</tbody>
    </table>
  </div>`;
}

function renderFillInBlank(aid, ctx, pxH) {
  const sentences = aid.sentences || [];
  const wbGroups  = (aid.wordBank || Object.keys(ctx.wordLists)).map(k => ctx.wordLists[k]).filter(Boolean);
  const wbWords   = wbGroups.flatMap(g => g.words);

  // Split word bank into rows of 5 so many words never overflow horizontally
  const wordsPerRow = 5;
  const wbChunks = [];
  for (let i = 0; i < wbWords.length; i += wordsPerRow) wbChunks.push(wbWords.slice(i, i + wordsPerRow));

  const lblH   = Math.round(pxH * 0.06);
  const wbRowH = 28;                           // fixed px per word-bank row — always readable
  const wbH    = wbRowH * wbChunks.length;    // total word bank height scales with row count
  const sentH  = Math.floor((pxH - lblH - wbH - 4) / sentences.length);
  const wbFs   = pt(wbRowH * 0.7);
  const sentFs = pt(sentH * 0.7, 7, 16);

  const wbTableRows = wbChunks.map(chunk => {
    const cells = chunk.map(w =>
      `<td style="background:#fff;font-size:${wbFs}pt;font-weight:bold;
        padding:2px 4px;border:1px solid ${BORDER};text-align:center;">${w}</td>`
    ).join('');
    return `<tr style="height:${wbRowH}px;">${cells}</tr>`;
  }).join('');

  const sentRows = sentences.map((s, i) => `<tr style="height:${sentH}px;">
    <td style="border:none;padding:2px 6px;font-size:${sentFs}pt;
      white-space:nowrap;width:60%;vertical-align:middle;">${i+1}. ${s}</td>
    <td style="border:none;border-bottom:2px solid #000;padding:1px 4px;vertical-align:bottom;">&nbsp;</td>
  </tr>`).join('');

  return `<div style="height:${pxH}px;overflow:hidden;font-family:Arial,sans-serif;">
    <div style="height:${lblH}px;display:flex;align-items:center;">
      <span style="font-size:${pt(lblH*0.7)}pt;font-weight:bold;text-decoration:underline;">
        Fill in the Blank
      </span>
    </div>
    <div style="height:${wbH}px;overflow:hidden;">
      <table style="width:100%;border-collapse:collapse;height:100%;">${wbTableRows}</table>
    </div>
    <div style="height:4px;"></div>
    <table style="width:100%;border-collapse:collapse;table-layout:fixed;">
      <tbody>${sentRows}</tbody>
    </table>
  </div>`;
}

function renderMatchMeanings(aid, ctx, pxH) {
  const pairs = aid.pairs || [];
  const rh = rowH(pxH, pairs.length);
  const fs = pt(rh);
  const hdr = hdrRow(['Heart Word','What does it mean?'],['35%','65%']);
  const rows = pairs.map(p => `<tr style="height:${rh}px;">
    ${dataCell(p.word, '#fff', rh, fs)}
    <td style="font-size:${fs}pt;padding:2px 5px;border:1px solid ${BORDER};
      height:${rh}px;vertical-align:middle;">${p.meaning}</td>
  </tr>`).join('');

  return `<div style="height:${pxH}px;overflow:hidden;font-family:Arial,sans-serif;">
    <table style="width:100%;border-collapse:collapse;table-layout:fixed;height:${pxH}px;">
      <thead>${hdr}</thead><tbody>${rows}</tbody>
    </table>
  </div>`;
}

function renderCircleCorrect(aid, ctx, pxH) {
  const items = aid.items || [];
  const lblH  = Math.round(pxH * 0.10);
  const rh    = rowH(pxH, items.length, HDR_H, lblH);
  const fs    = pt(rh);
  const hdr   = hdrRow(['#','Option A','Option B','Option C'],['8%','30%','30%','32%']);

  // Shuffle options deterministically by word index
  const rows = items.map((item, i) => {
    const opts = [item.correct, ...item.distractors].sort((a,b) => a.localeCompare(b));
    const bg = '#ffffff';
    return `<tr style="height:${rh}px;">
      <td style="background:#fff;font-size:${fs}pt;font-weight:bold;text-align:center;
        border:1px solid ${BORDER};height:${rh}px;vertical-align:middle;">${i+1}.</td>
      ${opts.map(o => `<td style="background:#fff;font-size:${fs}pt;text-align:center;
        border:1px solid ${BORDER};height:${rh}px;vertical-align:middle;">[ ] ${o}</td>`).join('')}
    </tr>`;
  }).join('');

  return `<div style="height:${pxH}px;overflow:hidden;font-family:Arial,sans-serif;">
    <div style="height:${lblH}px;display:flex;align-items:center;">
      <span style="font-size:${pt(lblH*0.7)}pt;font-weight:bold;text-decoration:underline;">
        Circle the Right Spelling
      </span>
      <span style="font-size:${pt(lblH*0.55)}pt;color:#000;margin-left:6px;">
        — one word in each row is spelled correctly
      </span>
    </div>
    <table style="width:100%;border-collapse:collapse;table-layout:fixed;">
      <thead>${hdr}</thead><tbody>${rows}</tbody>
    </table>
  </div>`;
}

function renderUnscramble(aid, ctx, pxH) {
  const words = aid.words || [];
  function scramble(w) {
    if (w.length <= 3) return w.split('').reverse().join('');
    return w[0] + w.slice(1,-1).split('').reverse().join('') + w[w.length-1];
  }
  const half  = Math.ceil(words.length / 2);
  const col1  = words.slice(0, half);
  const col2  = words.slice(half);
  const lblH  = Math.round(pxH * 0.14);
  const itemH = Math.floor((pxH - lblH) / half);
  const fs    = pt(itemH * 0.65);

  const makeCol = (ws, offset) => ws.map((w, i) => `
    <div style="height:${itemH}px;display:flex;align-items:flex-end;gap:6px;padding:1px 0;">
      <span style="font-size:${fs}pt;font-weight:bold;min-width:20px;">${offset+i+1}.</span>
      <span style="font-size:${fs}pt;font-family:'Courier New',monospace;font-weight:bold;
        min-width:90px;">${scramble(w)}</span>
      <div style="flex:1;border-bottom:2px solid #000;">&nbsp;</div>
    </div>`).join('');

  return `<div style="height:${pxH}px;overflow:hidden;font-family:Arial,sans-serif;">
    <div style="height:${lblH}px;display:flex;align-items:center;">
      <span style="font-size:${pt(lblH*0.65)}pt;font-weight:bold;text-decoration:underline;">
        Unscramble the Letters
      </span>
    </div>
    <div style="display:flex;gap:20px;">
      <div style="flex:1;">${makeCol(col1, 0)}</div>
      <div style="flex:1;">${makeCol(col2, col1.length)}</div>
    </div>
  </div>`;
}

function renderWriteFromMemory(aid, ctx, pxH) {
  const words  = aid.words || [];
  const label  = aid.label || 'Write From Memory';
  const half   = Math.ceil(words.length / 2);
  const col1   = words.slice(0, half);
  const col2   = words.slice(half);
  const lblH   = Math.round(pxH * 0.10);
  const subH   = Math.round(pxH * 0.06);
  const itemH  = Math.floor((pxH - lblH - subH - 4) / half);
  const fs     = pt(itemH * 0.65);

  const makeCol = (ws, offset) => ws.map((w, i) => `
    <div style="height:${itemH}px;display:flex;align-items:flex-end;gap:6px;padding:1px 0;">
      <span style="font-size:${fs}pt;font-weight:bold;min-width:22px;">${offset+i+1}.</span>
      <div style="flex:1;border-bottom:2px solid #000;">&nbsp;</div>
    </div>`).join('');

  return `<div style="height:${pxH}px;overflow:hidden;font-family:Arial,sans-serif;">
    <div style="height:${lblH}px;display:flex;align-items:center;">
      <span style="font-size:${pt(lblH*0.65)}pt;font-weight:bold;text-decoration:underline;">${label}</span>
    </div>
    <div style="height:${subH}px;display:flex;align-items:center;">
      <span style="font-size:${pt(subH*0.65)}pt;color:#000;">Your teacher will say the word. You write it!</span>
    </div>
    <div style="display:flex;gap:20px;">
      <div style="flex:1;">${makeCol(col1, 0)}</div>
      <div style="flex:1;">${makeCol(col2, col1.length)}</div>
    </div>
  </div>`;
}

function renderPracticeTest(aid, ctx, pxH) {
  const words  = ctx.allWords;
  const half   = Math.ceil(words.length / 2);
  const col1   = words.slice(0, half);
  const col2   = words.slice(half);
  const subH   = Math.round(pxH * 0.05);
  const scoreH = Math.round(pxH * 0.10);
  const practH = Math.round(pxH * 0.12);
  const bodyH  = pxH - subH - scoreH - practH - 12;
  const itemH  = Math.floor(bodyH / half);
  const fs     = pt(itemH * 0.65);
  const scoreFs = pt(scoreH * 0.5);
  const practFs = pt(practH * 0.35);

  const makeCol = (ws, offset) => ws.map((w, i) => `
    <div style="height:${itemH}px;display:flex;align-items:flex-end;gap:6px;padding:1px 0;">
      <span style="font-size:${fs}pt;font-weight:bold;min-width:28px;">${offset+i+1}.</span>
      <div style="flex:1;border-bottom:2px solid #000;">&nbsp;</div>
    </div>`).join('');

  return `<div style="height:${pxH}px;overflow:hidden;font-family:Arial,sans-serif;display:flex;flex-direction:column;gap:4px;">
    <div style="height:${subH}px;font-size:${pt(subH*0.65)}pt;color:#000;display:flex;align-items:center;">
      Write each word as your teacher reads it aloud.
    </div>
    <div style="height:${bodyH}px;display:flex;gap:20px;flex-shrink:0;">
      <div style="flex:1;">${makeCol(col1, 0)}</div>
      <div style="flex:1;">${makeCol(col2, col1.length)}</div>
    </div>
    <div style="height:${scoreH}px;border:2px solid #000;display:flex;align-items:center;
      justify-content:center;font-size:${scoreFs}pt;font-weight:bold;flex-shrink:0;">
      My Score: &nbsp;&nbsp;____&nbsp;&nbsp;/&nbsp;&nbsp;${words.length}
    </div>
    <div style="height:${practH}px;border:2px solid #000;padding:4px 8px;flex-shrink:0;">
      <div style="font-size:${practFs}pt;font-weight:bold;">Words to practice more:</div>
      <div style="flex:1;border-bottom:1px solid #000;margin-top:6px;">&nbsp;</div>
    </div>
  </div>`;
}

function renderReminderCard(aid, ctx, pxH) {
  const groups = Object.values(ctx.wordLists);
  const allRows = groups.length + 1; // +hearts
  const topH = Math.round(pxH * 0.12);
  const rh = Math.floor((pxH - topH - HDR_H - 4) / allRows);
  const fs = pt(rh * 0.65);

  const hdr = hdrRow(['Pattern','Rule & Words'],['30%','70%']);
  const groupRows = groups.map(g => `<tr style="height:${rh}px;">
    <td style="background:#fff;font-size:${fs}pt;font-weight:bold;
      padding:2px 5px;border:1px solid ${BORDER};vertical-align:middle;">${g.name}</td>
    <td style="font-size:${fs}pt;padding:2px 5px;border:1px solid ${BORDER};vertical-align:middle;">
      <span style="color:#000;">${g.rule}</span>
      &nbsp;&nbsp;<b>${g.words.join('&nbsp;&nbsp;')}</b>
    </td>
  </tr>`).join('');
  const heartRow = `<tr style="height:${rh}px;">
    <td style="background:#fff;font-size:${fs}pt;font-weight:bold;
      padding:2px 5px;border:1px solid ${BORDER};vertical-align:middle;">Heart Words</td>
    <td style="font-size:${fs}pt;font-weight:bold;padding:2px 5px;border:1px solid ${BORDER};
      vertical-align:middle;">${ctx.heartWords.join('&nbsp;&nbsp;&nbsp;')}</td>
  </tr>`;

  return `<div style="height:${pxH}px;overflow:hidden;font-family:Arial,sans-serif;">
    <div style="height:${topH}px;border-top:2px dashed #000;display:flex;align-items:center;
      font-size:${pt(topH*0.6)}pt;font-weight:bold;">
      ✂ &nbsp;My Pattern Card — Cut Me Out!
    </div>
    <table style="width:100%;border-collapse:collapse;table-layout:fixed;">
      <thead>${hdr}</thead><tbody>${groupRows}${heartRow}</tbody>
    </table>
  </div>`;
}

function renderHeartLookCoverWrite(aid, ctx, pxH) {
  // Same layout as look-cover-write but for heart words with a distinct header label
  const words = ctx.heartWords;
  const rh = rowH(pxH, words.length);
  const fs = pt(rh);

  const hdr = hdrRow(['❤ Heart Word','Write it','Write it again','One more time!'],
                     ['22%','26%','26%','26%']);
  const rows = words.map(w => `<tr style="height:${rh}px;">
    ${dataCell(w, '#fff', rh, fs, 'text-align:center;')}
    ${blankCell(rh)}${blankCell(rh)}${blankCell(rh)}
  </tr>`).join('');

  return `<div style="height:${pxH}px;overflow:hidden;font-family:Arial,sans-serif;">
    <table style="width:100%;border-collapse:collapse;table-layout:fixed;height:${pxH}px;">
      <thead>${hdr}</thead><tbody>${rows}</tbody>
    </table>
  </div>`;
}

function renderHeartFillInBlank(aid, ctx, pxH) {
  // Fill-in-blank using only heart words as the word bank
  const sentences = aid.sentences || [];
  const words = ctx.heartWords;
  const wbH  = Math.round(pxH * 0.14);
  const lblH = Math.round(pxH * 0.08);
  const sentH = Math.floor((pxH - wbH - lblH - 4) / sentences.length);
  const wbFs  = pt(wbH * 0.7);
  const sentFs = pt(sentH * 0.7, 7, 16);

  const wbCells = words.map(w =>
    `<td style="background:#fff;font-size:${wbFs}pt;font-weight:bold;
      padding:2px 4px;border:1px solid ${BORDER};text-align:center;">❤ ${w}</td>`
  ).join('');

  const sentRows = sentences.map((s, i) => `<tr style="height:${sentH}px;">
    <td style="border:none;padding:2px 6px;font-size:${sentFs}pt;
      white-space:nowrap;width:60%;vertical-align:middle;">${i+1}. ${s}</td>
    <td style="border:none;border-bottom:2px solid #000;padding:1px 4px;vertical-align:bottom;">&nbsp;</td>
  </tr>`).join('');

  return `<div style="height:${pxH}px;overflow:hidden;font-family:Arial,sans-serif;">
    <div style="height:${lblH}px;display:flex;align-items:center;">
      <span style="font-size:${pt(lblH*0.7)}pt;font-weight:bold;text-decoration:underline;">
        ❤ Heart Word Fill in the Blank
      </span>
    </div>
    <div style="height:${wbH}px;overflow:hidden;">
      <table style="width:100%;border-collapse:collapse;height:100%;"><tr>${wbCells}</tr></table>
    </div>
    <div style="height:4px;"></div>
    <table style="width:100%;border-collapse:collapse;table-layout:fixed;">
      <tbody>${sentRows}</tbody>
    </table>
  </div>`;
}

// ── Registry ──────────────────────────────────────────────────────────────────
const RENDERERS = {
  'word-groups':              renderWordGroups,
  'look-cover-write':         renderLookCoverWrite,
  'fill-in-blank':            renderFillInBlank,
  'match-meanings':           renderMatchMeanings,
  'circle-correct':           renderCircleCorrect,
  'unscramble':               renderUnscramble,
  'write-from-memory':        renderWriteFromMemory,
  'practice-test':            renderPracticeTest,
  'reminder-card':            renderReminderCard,
  'heart-look-cover-write':   renderHeartLookCoverWrite,
  'heart-fill-in-blank':      renderHeartFillInBlank,
};

// ── Page builder ──────────────────────────────────────────────────────────────
function buildPageHTML(sheet, ctx) {
  const totalGaps = (sheet.aids.length - 1) * GAP;
  const bodyH = USABLE_H - TITLE_H - GAP - totalGaps;

  const aidPxHeights = sheet.aids.map(a => Math.round(a.h * bodyH));
  // Fix rounding
  const diff = bodyH - aidPxHeights.reduce((s, h) => s + h, 0);
  aidPxHeights[aidPxHeights.length - 1] += diff;

  const aidHTML = sheet.aids.map((aid, i) => {
    const renderer = RENDERERS[aid.type];
    const pxH = aidPxHeights[i];
    const inner = renderer
      ? renderer(aid, ctx, pxH)
      : `<div style="height:${pxH}px;border:1px dashed red;display:flex;align-items:center;
          justify-content:center;color:red;">Unknown: ${aid.type}</div>`;
    return `<div style="height:${pxH}px;flex-shrink:0;overflow:hidden;">${inner}</div>`;
  }).join(`<div style="height:${GAP}px;flex-shrink:0;"></div>`);

  const titleHTML = `<div style="height:${TITLE_H}px;background:${DARK};color:#fff;
    font-family:Arial,sans-serif;font-size:${pt(TITLE_H*0.7)}pt;font-weight:bold;
    display:flex;align-items:center;justify-content:center;margin-bottom:${GAP}px;
    flex-shrink:0;">${sheet.title}</div>`;

  return `<div style="
    width:${USABLE_W}px;height:${USABLE_H}px;margin:${MARGIN}px;
    display:flex;flex-direction:column;font-family:Arial,sans-serif;
    page-break-after:always;overflow:hidden;">
    ${titleHTML}${aidHTML}
  </div>`;
}

// ── Main ──────────────────────────────────────────────────────────────────────
async function generate(def, outputPath) {
  const ctx = {
    wordLists: def.wordLists,
    heartWords: def.heartWords,
    illustrations: def.illustrations || {},
    allWords: [
      ...Object.values(def.wordLists).flatMap(g => g.words),
      ...def.heartWords
    ]
  };

  const pages = def.sheets.map(s => buildPageHTML(s, ctx)).join('\n');

  const html = `<!DOCTYPE html><html><head><meta charset="utf-8">
<style>* { box-sizing:border-box; margin:0; padding:0; }
body { background:white; }
@media print { @page { size:letter; margin:0; } }
</style></head><body>${pages}</body></html>`;

  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });
  const page = await browser.newPage();
  await page.setContent(html, { waitUntil: 'networkidle' });
  const pdf = await page.pdf({ format: 'Letter', printBackground: true,
    margin: { top:0, right:0, bottom:0, left:0 } });
  await browser.close();

  fs.writeFileSync(outputPath, pdf);
  console.log(`✓ ${def.sheets.length} pages → ${outputPath}`);
}

module.exports = { generate };
