const engine = require('./worksheet_engine');
const def    = require('./three_day_def');

engine.generate(def, '/mnt/user-data/outputs/spelling_3day.pdf').catch(console.error);
