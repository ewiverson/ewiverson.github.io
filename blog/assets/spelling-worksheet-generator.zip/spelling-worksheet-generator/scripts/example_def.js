const illustrations = require('./svg_data_custom');

// All 10 spelling words + 4 heart words covered every day
// Structure: Day 1A/1B (intro), Day 2A/2B (practice), Day 3A/3B (challenge), Test page

const def = {
  title: "Spelling Words: -are, -air, -ear",
  illustrations,

  wordLists: {
    group1: {
      name: '-are words',
      rule: 'a-r-e says /air/ like in "care"',
      words: ['square', 'share', 'care', 'scare', 'chair'],
      color: '#ffffff'
    },
    group2: {
      name: '-air words',
      rule: '-air also says /air/ like "fair"',
      words: ['air', 'fair'],
      color: '#ffffff'
    },
    group3: {
      name: '-ear words',
      rule: '-ear can say /air/ too! like "bear"',
      words: ['pear', 'bear', 'wear'],
      color: '#ffffff'
    },
  },

  heartWords: ['once', 'upon', 'yellow', 'live'],

  sheets: [

    // ── DAY 1A: Intro — see and recognize ──────────────────────────────────────
    {
      title: 'Day 1 — Page A: Meet Your Words!',
      aids: [
        { type: 'word-groups', h: 0.48 },
        // Heart words intro: read and match meanings
        { type: 'match-meanings', h: 0.50,
          pairs: [
            { word: 'once',   meaning: 'one time only (Once upon a time…)' },
            { word: 'upon',   meaning: 'on top of something' },
            { word: 'yellow', meaning: 'a bright sunny color' },
            { word: 'live',   meaning: 'to be alive; where you call home' },
          ]
        },
      ]
    },

    // ── DAY 1B: Look-Cover-Write all words ─────────────────────────────────────
    {
      title: 'Day 1 — Page B: Look, Cover, Write!',
      aids: [
        { type: 'look-cover-write', h: 0.65, groups: ['group1', 'group2', 'group3'] },
        // Heart words look-cover-write (reuse the same aid, pass as extra words via fill workaround)
        { type: 'heart-look-cover-write', h: 0.33 },
      ]
    },

    // ── DAY 2A: Fill-in-blank + circle-correct ─────────────────────────────────
    {
      title: 'Day 2 — Page A: Practice Your Words!',
      aids: [
        { type: 'fill-in-blank', h: 0.52, wordBank: ['group1', 'group2', 'group3'],
          sentences: [
            'I like to _____ my toys with my friend.',
            'Please _____ for the hot pot on the stove!',
            'The ghost tried to _____ us on Halloween.',
            'A _____ has four equal sides.',
            'She sat in the big soft _____ by the window.',
            'A _____ is a sweet yellow-green fruit.',
            'The _____ floated gently up in the sky.',
            'Is it _____ to take turns on the swings?',
          ]
        },
        { type: 'heart-fill-in-blank', h: 0.46,
          sentences: [
            'The story began _____ upon a time, long ago.',
            'She only asked _____ , and then she was quiet.',
            'The _____ sun shone all day long.',
            'Fish and frogs _____ near the pond.',
          ]
        },
      ]
    },

    // ── DAY 2B: Circle-correct + Unscramble ────────────────────────────────────
    {
      title: 'Day 2 — Page B: Choose & Unscramble!',
      aids: [
        { type: 'circle-correct', h: 0.52,
          items: [
            { correct: 'share',  distractors: ['shair',  'shear']  },
            { correct: 'care',   distractors: ['cair',   'kare']   },
            { correct: 'bear',   distractors: ['bare',   'bair']   },
            { correct: 'fair',   distractors: ['fare',   'feer']   },
            { correct: 'square', distractors: ['sqwear', 'squair'] },
            { correct: 'once',   distractors: ['wonce',  'onse']   },
            { correct: 'wear',   distractors: ['ware',   'wair']   },
            { correct: 'yellow', distractors: ['yello',  'yelow']  },
            { correct: 'scare',  distractors: ['scair',  'skare']  },
            { correct: 'upon',   distractors: ['apon',   'upen']   },
          ]
        },
        { type: 'unscramble', h: 0.46,
          words: ['pear', 'chair', 'scare', 'air', 'live', 'upon', 'wear', 'fair']
        },
      ]
    },

    // ── DAY 3A: Write from memory + harder fill-in-blank ──────────────────────
    {
      title: 'Day 3 — Page A: Challenge Round!',
      aids: [
        { type: 'write-from-memory', h: 0.44,
          words: ['square', 'share', 'care', 'scare', 'chair', 'air', 'fair', 'pear', 'bear', 'wear'],
          label: 'Write From Memory — Spelling Words'
        },
        { type: 'heart-fill-in-blank', h: 0.54,
          sentences: [
            'The princess will _____ in her castle happily ever after.',
            'She sat _____ the big chair to read.',
            'The _____ balloon drifted high in the sky.',
            'We _____ near the park, just down the road.',
            '_____ a day, the farmer fed all his animals.',
            'They built a fort _____ a pile of pillows.',
          ]
        },
      ]
    },

    // ── DAY 3B: Write heart words from memory + full unscramble ───────────────
    {
      title: 'Day 3 — Page B: Almost There!',
      aids: [
        { type: 'write-from-memory', h: 0.30,
          words: ['once', 'upon', 'yellow', 'live'],
          label: 'Write From Memory — Heart Words'
        },
        { type: 'unscramble', h: 0.32,
          words: ['square', 'share', 'yellow', 'scare', 'once', 'bear', 'upon', 'live']
        },
        { type: 'fill-in-blank', h: 0.36, wordBank: ['group1', 'group2', 'group3'],
          sentences: [
            'The baby _____ at the zoo looked fluffy and round.',
            'Dad likes to _____ his cozy hat on cold days.',
            'I breathe fresh _____ when I run outside.',
            'The _____ ride at the fair went around and around.',
          ]
        },
      ]
    },

    // ── PRACTICE TEST + REMINDER CARD ─────────────────────────────────────────
    {
      title: "Practice Test — You've Got This!",
      aids: [
        { type: 'practice-test',  h: 0.72 },
        { type: 'reminder-card',  h: 0.26 },
      ]
    },
  ]
};

module.exports = def;
