// All SVGs: black strokes on white — no gray, no color fills

function svgToDataURI(svg) {
  return 'data:image/svg+xml;base64,' + Buffer.from(svg).toString('base64');
}

const BK = 'stroke="#000" fill="none"';
const SW = 'stroke-width';

const svgs = {};

// square — bold outlined square with corner marks
svgs['square'] = svgToDataURI(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80">
  <rect x="12" y="12" width="56" height="56" fill="white" stroke="#000" stroke-width="5" rx="2"/>
  <line x1="12" y1="12" x2="22" y2="22" stroke="#000" stroke-width="3"/>
  <line x1="68" y1="12" x2="58" y2="22" stroke="#000" stroke-width="3"/>
  <line x1="12" y1="68" x2="22" y2="58" stroke="#000" stroke-width="3"/>
  <line x1="68" y1="68" x2="58" y2="58" stroke="#000" stroke-width="3"/>
  <text x="40" y="47" font-family="Arial" font-size="11" font-weight="bold" text-anchor="middle" fill="#000">square</text>
</svg>`);

// chair — simple side-view chair, outline only
svgs['chair'] = svgToDataURI(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80">
  <!-- seat -->
  <rect x="18" y="42" width="48" height="8" fill="white" stroke="#000" stroke-width="4" rx="2"/>
  <!-- back post -->
  <line x1="24" y1="42" x2="24" y2="12" stroke="#000" stroke-width="4" stroke-linecap="round"/>
  <!-- back top rail -->
  <rect x="16" y="10" width="16" height="8" fill="white" stroke="#000" stroke-width="3" rx="2"/>
  <!-- back mid rail -->
  <rect x="16" y="24" width="16" height="7" fill="white" stroke="#000" stroke-width="3" rx="2"/>
  <!-- front leg -->
  <line x1="58" y1="50" x2="58" y2="72" stroke="#000" stroke-width="4" stroke-linecap="round"/>
  <!-- back leg -->
  <line x1="24" y1="50" x2="24" y2="72" stroke="#000" stroke-width="4" stroke-linecap="round"/>
</svg>`);

// pear — outline pear shape with stem and leaf
svgs['pear'] = svgToDataURI(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80">
  <!-- body -->
  <ellipse cx="40" cy="54" rx="22" ry="20" fill="white" stroke="#000" stroke-width="4"/>
  <!-- top bulge -->
  <ellipse cx="40" cy="34" rx="12" ry="13" fill="white" stroke="#000" stroke-width="4"/>
  <!-- stem -->
  <line x1="40" y1="21" x2="43" y2="12" stroke="#000" stroke-width="3" stroke-linecap="round"/>
  <!-- leaf outline -->
  <ellipse cx="50" cy="12" rx="7" ry="4" fill="white" stroke="#000" stroke-width="2.5" transform="rotate(-30 50 12)"/>
  <!-- leaf vein -->
  <line x1="44" y1="14" x2="56" y2="10" stroke="#000" stroke-width="1.5" stroke-linecap="round" transform="rotate(-30 50 12)"/>
</svg>`);

// bear — front-face outline bear
svgs['bear'] = svgToDataURI(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80">
  <!-- ears -->
  <circle cx="22" cy="22" r="11" fill="white" stroke="#000" stroke-width="3.5"/>
  <circle cx="58" cy="22" r="11" fill="white" stroke="#000" stroke-width="3.5"/>
  <!-- inner ear -->
  <circle cx="22" cy="22" r="5" fill="white" stroke="#000" stroke-width="2"/>
  <circle cx="58" cy="22" r="5" fill="white" stroke="#000" stroke-width="2"/>
  <!-- head -->
  <circle cx="40" cy="44" r="26" fill="white" stroke="#000" stroke-width="4"/>
  <!-- snout -->
  <ellipse cx="40" cy="53" rx="12" ry="8" fill="white" stroke="#000" stroke-width="2.5"/>
  <!-- nose -->
  <ellipse cx="40" cy="48" rx="4.5" ry="3" fill="#000"/>
  <!-- eyes -->
  <circle cx="30" cy="38" r="3.5" fill="#000"/>
  <circle cx="50" cy="38" r="3.5" fill="#000"/>
  <circle cx="31" cy="37" r="1.2" fill="white"/>
  <circle cx="51" cy="37" r="1.2" fill="white"/>
  <!-- mouth -->
  <path d="M35 57 Q40 62 45 57" fill="none" stroke="#000" stroke-width="2.5" stroke-linecap="round"/>
</svg>`);

// air — cloud outline with wind lines
svgs['air'] = svgToDataURI(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80">
  <!-- cloud outline (composed path) -->
  <circle cx="30" cy="34" r="13" fill="white" stroke="#000" stroke-width="3"/>
  <circle cx="47" cy="34" r="11" fill="white" stroke="#000" stroke-width="3"/>
  <circle cx="38" cy="26" r="12" fill="white" stroke="#000" stroke-width="3"/>
  <!-- cloud base fill-white to merge the circles visually -->
  <rect x="22" y="34" width="36" height="12" fill="white"/>
  <line x1="22" y1="46" x2="58" y2="46" stroke="#000" stroke-width="3"/>
  <!-- wind lines below -->
  <line x1="12" y1="56" x2="52" y2="56" stroke="#000" stroke-width="3" stroke-linecap="round"/>
  <line x1="16" y1="63" x2="62" y2="63" stroke="#000" stroke-width="3" stroke-linecap="round"/>
  <line x1="20" y1="70" x2="48" y2="70" stroke="#000" stroke-width="3" stroke-linecap="round"/>
</svg>`);

// fair — ferris wheel outline
svgs['fair'] = svgToDataURI(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80">
  <!-- wheel rim -->
  <circle cx="40" cy="34" r="26" fill="white" stroke="#000" stroke-width="4"/>
  <!-- hub -->
  <circle cx="40" cy="34" r="4" fill="#000"/>
  <!-- spokes -->
  <line x1="40" y1="8"  x2="40" y2="60" stroke="#000" stroke-width="2"/>
  <line x1="14" y1="34" x2="66" y2="34" stroke="#000" stroke-width="2"/>
  <line x1="21.6" y1="15.6" x2="58.4" y2="52.4" stroke="#000" stroke-width="2"/>
  <line x1="58.4" y1="15.6" x2="21.6" y2="52.4" stroke="#000" stroke-width="2"/>
  <!-- gondolas -->
  <rect x="36" y="4"  width="8" height="6" fill="white" stroke="#000" stroke-width="2" rx="1"/>
  <rect x="36" y="56" width="8" height="6" fill="white" stroke="#000" stroke-width="2" rx="1"/>
  <rect x="8"  y="30" width="8" height="6" fill="white" stroke="#000" stroke-width="2" rx="1"/>
  <rect x="63" y="30" width="8" height="6" fill="white" stroke="#000" stroke-width="2" rx="1"/>
  <!-- legs -->
  <line x1="40" y1="60" x2="28" y2="76" stroke="#000" stroke-width="3.5" stroke-linecap="round"/>
  <line x1="40" y1="60" x2="52" y2="76" stroke="#000" stroke-width="3.5" stroke-linecap="round"/>
  <line x1="25" y1="76" x2="55" y2="76" stroke="#000" stroke-width="3.5" stroke-linecap="round"/>
</svg>`);

// wear — t-shirt outline
svgs['wear'] = svgToDataURI(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80">
  <path d="M22 28 L10 16 L28 10 L40 20 L52 10 L70 16 L58 28 L58 72 L22 72 Z"
        fill="white" stroke="#000" stroke-width="4" stroke-linejoin="round"/>
  <!-- collar -->
  <path d="M28 10 Q40 26 52 10" fill="white" stroke="#000" stroke-width="3"/>
</svg>`);

// scare — ghost outline
svgs['scare'] = svgToDataURI(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80">
  <path d="M20 70 Q20 18 40 12 Q60 18 60 70 Q54 61 48 70 Q44 61 40 70 Q36 61 32 70 Q26 61 20 70 Z"
        fill="white" stroke="#000" stroke-width="4" stroke-linejoin="round"/>
  <!-- eyes -->
  <ellipse cx="32" cy="40" rx="5" ry="7" fill="#000"/>
  <ellipse cx="48" cy="40" rx="5" ry="7" fill="#000"/>
  <!-- eye shine -->
  <circle cx="34" cy="38" r="2" fill="white"/>
  <circle cx="50" cy="38" r="2" fill="white"/>
  <!-- mouth -->
  <path d="M33 54 Q40 61 47 54" fill="none" stroke="#000" stroke-width="2.5" stroke-linecap="round"/>
</svg>`);

// share — two stick figures with object between them
svgs['share'] = svgToDataURI(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80">
  <!-- left figure -->
  <circle cx="15" cy="14" r="7" fill="white" stroke="#000" stroke-width="3"/>
  <line x1="15" y1="21" x2="15" y2="46" stroke="#000" stroke-width="3" stroke-linecap="round"/>
  <line x1="15" y1="30" x2="5"  y2="40" stroke="#000" stroke-width="3" stroke-linecap="round"/>
  <line x1="15" y1="30" x2="28" y2="38" stroke="#000" stroke-width="3" stroke-linecap="round"/>
  <line x1="15" y1="46" x2="8"  y2="60" stroke="#000" stroke-width="3" stroke-linecap="round"/>
  <line x1="15" y1="46" x2="22" y2="60" stroke="#000" stroke-width="3" stroke-linecap="round"/>
  <!-- right figure -->
  <circle cx="65" cy="14" r="7" fill="white" stroke="#000" stroke-width="3"/>
  <line x1="65" y1="21" x2="65" y2="46" stroke="#000" stroke-width="3" stroke-linecap="round"/>
  <line x1="65" y1="30" x2="75" y2="40" stroke="#000" stroke-width="3" stroke-linecap="round"/>
  <line x1="65" y1="30" x2="52" y2="38" stroke="#000" stroke-width="3" stroke-linecap="round"/>
  <line x1="65" y1="46" x2="58" y2="60" stroke="#000" stroke-width="3" stroke-linecap="round"/>
  <line x1="65" y1="46" x2="72" y2="60" stroke="#000" stroke-width="3" stroke-linecap="round"/>
  <!-- shared star between them -->
  <polygon points="40,26 42,33 49,33 43,37 46,44 40,40 34,44 37,37 31,33 38,33"
           fill="white" stroke="#000" stroke-width="2.5" stroke-linejoin="round"/>
</svg>`);

// care — hand cradling a heart
svgs['care'] = svgToDataURI(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80">
  <!-- cupped hand / palm -->
  <path d="M16 56 Q16 68 40 70 Q64 68 64 56 Q64 48 56 46 L52 32 Q52 28 48 28 Q44 28 44 32 L44 44
           L42 28 Q42 24 38 24 Q34 24 34 28 L34 44
           L32 30 Q32 26 28 26 Q24 26 24 30 L24 46 Q16 48 16 56 Z"
        fill="white" stroke="#000" stroke-width="3" stroke-linejoin="round"/>
  <!-- heart above palm -->
  <path d="M33 20 Q40 10 47 20 Q54 28 40 38 Q26 28 33 20 Z"
        fill="white" stroke="#000" stroke-width="3" stroke-linejoin="round"/>
</svg>`);

module.exports = svgs;
