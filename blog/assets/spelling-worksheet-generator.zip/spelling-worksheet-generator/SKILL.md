---
name: spelling-worksheet-generator
description: Generate printable spelling practice worksheets for early elementary students (grades K–3) as a multi-page PDF. Use this skill whenever a user asks to create spelling worksheets, spelling practice sheets, a spelling study plan, or any printable spelling activity for young children. Also trigger when a user provides a spelling word list and asks for printable practice, a multi-night study plan, or activities like "look cover write," "fill in the blank," or "practice test." Always use this skill — even if the request seems brief like "make spelling worksheets for my second grader" — because the workflow requires phonetic analysis, learning-aid selection, and layout generation that benefits from these detailed instructions. Trigger even when the user uploads a photo of a word list.
---

# Spelling Worksheet Generator

Generates letter-sized, **print-ready PDFs** using an HTML→PDF layout engine (Playwright + Chromium). Output is pure **black text and strokes on white** — no gray, no color. Prints cleanly on any black-and-white printer.

Each sheet is declared as a stack of **learning aids**, each occupying a fraction of the page height. Fonts, row heights, and spacing are computed automatically from the rendered pixel dimensions. No manual sizing needed.

## Workflow

```
1. Analyze word list      → group words by phonetic pattern; identify heart/sight words
2. Generate SVG images    → black-stroke/white-fill line art for concrete words
3. Sequence the aids      → 3-day progression (2 pages/day) + 1 practice test page = 7 pages
4. Write the def file     → declare wordLists, heartWords, illustrations, sheets[]
5. Run the engine         → node run.js  →  multi-page PDF
```

## File Locations (relative to this skill)

```
scripts/worksheet_engine.js   ← layout engine — read before generating; do not edit
scripts/example_def.js        ← full 7-page 3-day worked example (same -are/-air/-ear set)
scripts/run.js                ← runner; edit outputPath and def require() path
```

## Step 1 — Analyze the Word List

Group spelling words by shared phonetic pattern (e.g. `-are`, `-air`, `-ear`). Assign each group:
- a short `name` (shown as column header)
- a one-line `rule` (explains the pattern to the child)
- `color: '#ffffff'` — **always white**; no gray or colored backgrounds

Identify **heart words** (sight words that don't follow a pattern: *once, upon, the, said*). These go in `heartWords[]` and get their own dedicated aids (`heart-look-cover-write`, `heart-fill-in-blank`, `match-meanings`).

## Step 2 — Generate SVG Illustrations

For each word that can be drawn simply (objects, animals, shapes), generate a black-and-white SVG:

**Rules for SVGs:**
- `fill="white"` or `fill="none"` only — never gray or colored fills
- `stroke="#000"` only — no gray strokes
- No `opacity` shading
- Viewbox `0 0 80 80`, exported as base64 data URI
- Simple outlines: shapes, stick figures, objects — readable at small sizes (~60px)

```js
function svgToDataURI(svg) {
  return 'data:image/svg+xml;base64,' + Buffer.from(svg).toString('base64');
}

svgs['bear'] = svgToDataURI(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80">
  <circle cx="40" cy="44" r="26" fill="white" stroke="#000" stroke-width="4"/>
  <!-- ... etc -->
</svg>`);
```

Store as a JS module (`svg_data_custom.js`) that exports the map, then pass as `illustrations` in the def:
```js
const illustrations = require('./svg_data_custom');
const def = { illustrations, wordLists: { ... }, ... };
```

## Step 3 — Sequence the Aids (3-Day + Test Structure)

Standard 7-page layout:

| Page | Day | Focus | Aids |
|------|-----|-------|------|
| 1A | Day 1 | Intro — see & recognize | `word-groups` + `match-meanings` |
| 1B | Day 1 | Trace & copy | `look-cover-write` (all groups) + `heart-look-cover-write` |
| 2A | Day 2 | Read in context | `fill-in-blank` (spelling words) + `heart-fill-in-blank` |
| 2B | Day 2 | Choose & decode | `circle-correct` + `unscramble` |
| 3A | Day 3 | Recall from nothing | `write-from-memory` (spelling) + `heart-fill-in-blank` (harder, no scaffolding) |
| 3B | Day 3 | Full recall | `write-from-memory` (heart words) + `unscramble` + `fill-in-blank` |
| 7  | Test | Summative | `practice-test` + `reminder-card` |

**All spelling words AND heart words must appear on every day's pages.**

Heart words get their own dedicated aid sections (with ❤ markers in headers) rather than being mixed into spelling word aids.

## Step 4 — Write the Definition File

```js
const illustrations = require('./svg_data_custom');

const def = {
  title: "Spelling Words: -are, -air, -ear",
  illustrations,

  wordLists: {
    group1: {
      name: '-are words',
      rule: 'a-r-e says /air/ like in "care"',
      words: ['square', 'share', 'care', 'scare', 'chair'],
      color: '#ffffff'       // always white
    },
    group2: {
      name: '-air words',
      rule: '-air also says /air/ like "fair"',
      words: ['air', 'fair'],
      color: '#ffffff'
    },
    group3: {
      name: '-ear words',
      rule: '-ear can say /air/ too! like "bear"',
      words: ['pear', 'bear', 'wear'],
      color: '#ffffff'
    },
  },

  heartWords: ['once', 'upon', 'yellow', 'live'],

  sheets: [
    {
      title: 'Day 1 — Page A: Meet Your Words!',
      aids: [
        { type: 'word-groups', h: 0.48 },
        { type: 'match-meanings', h: 0.50,
          pairs: [
            { word: 'once',   meaning: 'one time only' },
            { word: 'upon',   meaning: 'on top of something' },
            { word: 'yellow', meaning: 'a bright sunny color' },
            { word: 'live',   meaning: 'to be alive; where you call home' },
          ]
        },
      ]
    },
    // ... more sheets (see example_def.js for the full 7-page set)
  ]
};

module.exports = def;
```

**`h` values** are fractions of usable page body height. They must sum to ≤ 1.0 per sheet. Keep 2–3 aids per sheet.

## Step 5 — Run

```bash
cd path/to/skill/scripts
node run.js
# → PDF written to the path set in run.js
```

Requires Node.js with `playwright` installed (`npm install playwright`).
Chromium path may need to be set in `worksheet_engine.js` if auto-download fails:
```js
// In generate(), replace:
const browser = await chromium.launch();
// With:
const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });
```

---

## Aid Type Reference

### `word-groups`
Three-column display of all word groups with pattern name + rule headers and words listed below. Shows SVG illustrations inline if provided.
```js
{ type: 'word-groups', h: 0.48 }
```
Uses all `wordLists` automatically. Illustrations pulled from `ctx.illustrations` by word key.

---

### `look-cover-write`
Four-column table: **Word | Write it | Write it again | One more time!**
```js
{ type: 'look-cover-write', h: 0.65, groups: ['group1', 'group2', 'group3'] }
```
- `groups`: array of wordList keys to include (omit to use all groups)
- Height rule: needs ≥ 0.08 per word in the selected groups

---

### `heart-look-cover-write`
Same layout as `look-cover-write` but for heart words, with a ❤ header marker.
```js
{ type: 'heart-look-cover-write', h: 0.33 }
```
Uses `ctx.heartWords` automatically. No extra fields.

---

### `fill-in-blank`
Word bank row + numbered sentences with a blank (`_____`) and an answer line.
```js
{ type: 'fill-in-blank', h: 0.52, wordBank: ['group1', 'group2', 'group3'],
  sentences: [
    'I like to _____ my toys with my friend.',
    'The ghost tried to _____ us on Halloween.',
  ]
}
```
- `wordBank`: which groups to show in the word bank (omit to use all)
- `sentences`: array of strings; use `_____` for the blank

**⚠ How to generate sentences — two-step process (do NOT skip this):**

LLMs are unreliable at placing blanks correctly in one shot. Always use this two-step approach:

**Step 1 — Write complete sentences.** For each spelling word, write a short, simple, age-appropriate sentence (K–3 reading level) that naturally uses the target word. Write the full sentence with the actual word — no blanks yet. Example for the word `share`:
> *"I like to share my toys with my friend."*

**Step 2 — Replace the target word programmatically.** After composing all sentences, run this snippet to insert the blank:

```python
def make_fill_in_blank(sentence: str, target_word: str) -> str:
    import re
    pattern = re.compile(r'\b' + re.escape(target_word) + r'\b', re.IGNORECASE)
    result = pattern.sub('_____', sentence, count=1)
    assert '_____' in result, f"Word '{target_word}' not found in sentence: {sentence}"
    return result
```

Or in JavaScript (inside the def file build process):
```js
function makeBlank(sentence, targetWord) {
  const pattern = new RegExp(`\\b${targetWord}\\b`, 'i');
  const result = sentence.replace(pattern, '_____');
  if (!result.includes('_____')) throw new Error(`Word '${targetWord}' not found in: ${sentence}`);
  return result;
}
```

Use this function to produce the final `sentences` array. Never hand-write a sentence with `_____` directly.

**⚠ Sentence validation — check every sentence before writing the def file:**
1. **Answer must be in the word bank.** Confirm the target word is in the `wordBank` groups. Never write a sentence where the intended answer is not on the list.
2. **Exactly one blank per sentence.** The regex replaces only the first match (`count=1` / no `g` flag); confirm the target word appears only once in the sentence.
3. **Exactly one valid answer.** The blank should not be fillable by more than one word from the word bank.
4. **No other list words in the sentence.** Don't use a different spelling-list word as part of the sentence text — it creates confusion about which word is the answer.

---

### `heart-fill-in-blank`
Fill-in-blank using only heart words as the word bank, with ❤ markers.
```js
{ type: 'heart-fill-in-blank', h: 0.46,
  sentences: [
    'The story began _____ upon a time, long ago.',
    'The _____ sun shone all day long.',
  ]
}
```
Uses `ctx.heartWords` as the word bank automatically.

**⚠ How to generate sentences — same two-step process as `fill-in-blank`:**
Apply the same generate-then-replace workflow: write complete sentences with the heart word present, then use `makeBlank()` / `make_fill_in_blank()` to substitute the blank programmatically. Never write `_____` by hand.

**⚠ Sentence validation — same rules as `fill-in-blank` above, plus:**
5. **Answer must be a heart word.** Read the sentence aloud with each heart word substituted in. Only one should sound natural and make sense — that confirms it's the right answer and that the answer is actually on the heart word list.

---

### `match-meanings`
Two-column table: **Heart Word | What does it mean?** — great for sight words on Day 1.
```js
{ type: 'match-meanings', h: 0.50,
  pairs: [
    { word: 'once',   meaning: 'one time only (Once upon a time…)' },
    { word: 'upon',   meaning: 'on top of something' },
    { word: 'yellow', meaning: 'a bright sunny color' },
    { word: 'live',   meaning: 'to be alive; where you call home' },
  ]
}
```

---

### `circle-correct`
Four-column table: **# | Option A | Option B | Option C** — student circles the correctly-spelled word. Options sorted alphabetically so correct answer isn't always in the same column.
```js
{ type: 'circle-correct', h: 0.52,
  items: [
    { correct: 'share',  distractors: ['shair', 'shear'] },
    { correct: 'bear',   distractors: ['bare',  'bair']  },
    { correct: 'once',   distractors: ['wonce', 'onse']  },
  ]
}
```
- `distractors`: exactly 2 plausible misspellings per word
- Include both spelling words and heart words

---

### `unscramble`
Two-column layout: scrambled word in monospace → blank answer line.
Scramble logic: keeps first and last letters, reverses the middle.
```js
{ type: 'unscramble', h: 0.32,
  words: ['square', 'share', 'yellow', 'scare', 'once', 'bear', 'upon', 'live']
}
```

---

### `write-from-memory`
Numbered write-in lines in two columns, no word visible. Teacher reads the word aloud.
```js
{ type: 'write-from-memory', h: 0.44,
  words: ['square', 'share', 'care', 'scare', 'chair', 'air', 'fair', 'pear', 'bear', 'wear'],
  label: 'Write From Memory — Spelling Words'
}
```
Use separate instances for spelling words and heart words on Day 3.

---

### `practice-test`
Full dictation test for all words (`wordLists` + `heartWords`), two-column numbered lines,
score box, and "words to practice more" box.
```js
{ type: 'practice-test', h: 0.72 }
```
Uses `ctx.allWords` automatically.

---

### `reminder-card`
Cut-out reference card with dashed border. Shows all patterns + rules + words + heart words.
Always pair with `practice-test` as the final aid on the last sheet.
```js
{ type: 'reminder-card', h: 0.26 }
```

---

## Layout Tips

| Scenario | Suggested h split |
|----------|------------------|
| 2-aid sheet | 0.48 / 0.50 or 0.52 / 0.46 |
| 3-aid sheet | 0.44 / 0.32 / 0.22 or 0.36 / 0.32 / 0.30 |
| practice-test + reminder-card | 0.72 / 0.26 |
| word-groups alone | 0.40–0.52 depending on word count |

If an aid overflows its box, increase `h` and decrease another aid's `h` to compensate.

---

## Color Rules (CRITICAL)

**All colors must be pure black or white — no exceptions:**
- `stroke="#000"` or `stroke-width` colors: always `#000` or `#000000`
- `fill`: always `#fff`, `#ffffff`, `white`, or `none`
- No gray hex values: `#aaa`, `#ccc`, `#555`, `#444`, `#595959`, `#f5f5f5`, etc. are all forbidden
- No `opacity` on fills (creates visual gray)
- No alternating row background colors
- Engine constants: `DARK = '#000000'`, `MID = '#000000'`, `BORDER = '#000000'`

---

## Adding a New Aid Type

1. Write a renderer in `worksheet_engine.js`:

```js
function renderMyAid(aid, ctx, pxH) {
  // aid  = the aid object from the sheet definition
  // ctx  = { wordLists, heartWords, allWords, illustrations }
  // pxH  = exact pixel height this aid must fill
  const nRows = aid.items.length;
  const HDR   = 26;
  const rh    = Math.floor((pxH - HDR) / nRows);
  const fs    = Math.min(22, Math.max(7, Math.round(rh * 0.48)));
  return `<div style="height:${pxH}px;overflow:hidden;font-family:Arial,sans-serif;">
    ...your HTML — black/white only...
  </div>`;
}
```

2. Register it in the RENDERERS map:
```js
const RENDERERS = {
  ...
  'my-aid': renderMyAid,
};
```

**Key constraint**: returned HTML must not exceed `pxH` pixels tall. Use `overflow:hidden` on the outer div. Always set explicit pixel heights on rows.

---

## Engine Architecture Notes

- **Page size**: Letter (816 × 1056 px at 96 dpi), 48 px margins → 720 × 960 px usable
- **Title bar**: 34 px, black (`#000000`), white bold text — reserved at top of each sheet
- **Gap between aids**: 8 px
- **Body height**: `960 − 34 − 8 − (n_aids − 1) × 8` px, distributed by `h` fractions
- **Font sizing**: `pt = clamp(round(rowHeightPx × 0.48), 7, 22)`
- **Colors**: black borders and headers only; all data cells white — prints cleanly
- **PDF generation**: Playwright `page.pdf({ format: 'Letter', printBackground: true })`; one CSS `page-break-after:always` div per sheet
